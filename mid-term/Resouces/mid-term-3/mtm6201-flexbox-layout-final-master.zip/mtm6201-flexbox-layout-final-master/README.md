# Flexbox Layout

## Objective
Use flexbox to create the basic layout of the provided mockup.
